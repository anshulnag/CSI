def left_aligned():
    for i in range(10, 0, -1):
        print("*" * i)


def left_aligned_inverted():
    for i in range(10):
        print("*" * i)


def centered_triangle():
    for i in range(10):
        spaces = " " * (10 - i - 1)
        stars = "*" * (2 * i + 1)
        print(spaces + stars)


def right_aligned_triangle():
    for i in range(1, 10 + 1):
        spaces = " " * (10 - i)
        stars = "*" * i
        print(spaces + stars)


def right_aligned_inverted_triangle():
    for i in range(10, 0, -1):
        spaces = " " * (10 - i)
        stars = "*" * i
        print(spaces + stars)


right_aligned_inverted_triangle()
right_aligned_triangle()
left_aligned()
left_aligned_inverted()
centered_triangle()

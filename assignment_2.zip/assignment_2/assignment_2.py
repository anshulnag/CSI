class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return

        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def print_list(self):
        if not self.head:
            print("List is empty")
            return

        current = self.head
        elements = []
        while current:
            elements.append(str(current.data))
            current = current.next
        print(" -> ".join(elements))

    def delete_nth(self, n):
        if not self.head:
            raise ValueError("Cannot delete from an empty list")

        if n < 1:
            raise ValueError("Index must be positive")

        # Special case: deleting the head
        if n == 1:
            self.head = self.head.next
            return

        current = self.head
        count = 1

        # Traverse to the node before the one to delete
        while current and count < n - 1:
            current = current.next
            count += 1

        if not current or not current.next:
            raise IndexError("Index out of range")

        # Delete the nth node by updating the next pointer
        current.next = current.next.next


def test_linked_list():
    ll = LinkedList()

    # Test 1: Adding elements
    print("Test 1: Adding elements")
    ll.append(1)
    ll.append(2)
    ll.append(3)
    ll.append(4)
    print("Initial list:", end=" ")
    ll.print_list()

    # Test 2: Deleting the 2nd node
    print("\nTest 2: Deleting 2nd node")
    try:
        ll.delete_nth(2)
        print("After deleting 2nd node:", end=" ")
        ll.print_list()
    except Exception as e:
        print(f"Error: {e}")

    # Test 3: Deleting from empty list
    print("\nTest 3: Deleting from empty list")
    empty_list = LinkedList()
    try:
        empty_list.delete_nth(1)
    except ValueError as e:
        print(f"Error: {e}")

    # Test 4: Deleting with invalid index
    print("\nTest 4: Deleting with invalid index")
    try:
        ll.delete_nth(10)
    except IndexError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    test_linked_list()
